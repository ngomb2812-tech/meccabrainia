import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Menu, X, ArrowRight, Zap, Settings, Cpu, Shield, Clock, Eye } from "lucide-react";

const aiServices = [
  { 
    icon: Settings, 
    title: "IA Maintenance", 
    description: "Prévision, diagnostic et réparation automatisés", 
    image: "https://images.unsplash.com/photo-1581094288338-2314dddb7ece?ixlib=rb-4.0.3&auto=format&fit=crop&w=3840&q=80", 
    monthly: "899€/mois",
    oneTime: "14 999€",
    premium: "29 999€"
  },
  { 
    icon: Cpu, 
    title: "IA 3D CAD", 
    description: "Modélisation, plans et détection d'erreurs", 
    image: "https://images.unsplash.com/photo-1559827260-dc66d52bef19?ixlib=rb-4.0.3&auto=format&fit=crop&w=3840&q=80", 
    monthly: "1 199€/mois",
    oneTime: "19 999€",
    premium: "39 999€"
  },
  { 
    icon: Settings, 
    title: "IA CNC", 
    description: "Programmation, simulation et contrôle qualité", 
    image: "https://images.unsplash.com/photo-1565008447742-97f6f38c985c?ixlib=rb-4.0.3&auto=format&fit=crop&w=3840&q=80", 
    monthly: "1 349€/mois",
    oneTime: "22 999€",
    premium: "44 999€"
  },
  { 
    icon: Cpu, 
    title: "IA Robotique", 
    description: "Contrôle, surveillance et réglage de robots industriels", 
    image: "https://images.unsplash.com/photo-1485827404703-89b55fcc595e?ixlib=rb-4.0.3&auto=format&fit=crop&w=3840&q=80", 
    monthly: "1 799€/mois",
    oneTime: "29 999€",
    premium: "59 999€"
  },
  { 
    icon: Zap, 
    title: "IA IoT Industriel", 
    description: "Connectivité et supervision intelligente des machines", 
    image: "https://images.unsplash.com/photo-1518709268805-4e9042af2176?ixlib=rb-4.0.3&auto=format&fit=crop&w=3840&q=80", 
    monthly: "1 049€/mois",
    oneTime: "17 999€",
    premium: "34 999€"
  },
  { 
    icon: Settings, 
    title: "IA Usinage", 
    description: "Contrôle des tolérances, usure outils, géométrie", 
    image: "https://images.unsplash.com/photo-1565008447742-97f6f38c985c?ixlib=rb-4.0.3&auto=format&fit=crop&w=3840&q=80", 
    monthly: "899€/mois",
    oneTime: "14 999€",
    premium: "29 999€"
  },
  { 
    icon: Cpu, 
    title: "IA Métrologie", 
    description: "Contrôle dimensionnel et détection de défauts", 
    image: "https://images.unsplash.com/photo-1581094288338-2314dddb7ece?ixlib=rb-4.0.3&auto=format&fit=crop&w=3840&q=80", 
    monthly: "989€/mois",
    oneTime: "16 999€",
    premium: "32 999€"
  },
  { 
    icon: Zap, 
    title: "IA Moteurs", 
    description: "Réparation, calculs et reconception assistée", 
    image: "https://images.unsplash.com/photo-1559292878-4c8b8ad5dbb8?ixlib=rb-4.0.3&auto=format&fit=crop&w=3840&q=80", 
    monthly: "1 139€/mois",
    oneTime: "18 999€",
    premium: "37 999€"
  },
  { 
    icon: Settings, 
    title: "IA Hydraulique", 
    description: "Analyse de circuits, pompes, pressions", 
    image: "https://images.unsplash.com/photo-1581094289194-807d68168dc9?ixlib=rb-4.0.3&auto=format&fit=crop&w=3840&q=80", 
    monthly: "959€/mois",
    oneTime: "15 999€",
    premium: "31 999€"
  },
  { 
    icon: Cpu, 
    title: "IA Pneumatique", 
    description: "Optimisation et simulation des circuits pneumatiques", 
    image: "https://images.unsplash.com/photo-1559826847-aa87ba54bd1f?ixlib=rb-4.0.3&auto=format&fit=crop&w=3840&q=80", 
    monthly: "869€/mois",
    oneTime: "13 999€",
    premium: "27 999€"
  },
  { 
    icon: Zap, 
    title: "IA Conception mécanique", 
    description: "Assistance complète CAO + prototypage", 
    image: "https://images.unsplash.com/photo-1559827260-dc66d52bef19?ixlib=rb-4.0.3&auto=format&fit=crop&w=3840&q=80", 
    monthly: "1 499€/mois",
    oneTime: "24 999€",
    premium: "49 999€"
  },
  { 
    icon: Settings, 
    title: "IA Réparation", 
    description: "Détection de panne, solution immédiate", 
    image: "https://images.unsplash.com/photo-1581094288338-2314dddb7ece?ixlib=rb-4.0.3&auto=format&fit=crop&w=3840&q=80", 
    monthly: "749€/mois",
    oneTime: "12 999€",
    premium: "24 999€"
  },
  { 
    icon: Cpu, 
    title: "IA Automatisation", 
    description: "Création de lignes automatiques + algorithmes", 
    image: "https://images.unsplash.com/photo-1518709268805-4e9042af2176?ixlib=rb-4.0.3&auto=format&fit=crop&w=3840&q=80", 
    monthly: "2 099€/mois",
    oneTime: "34 999€",
    premium: "69 999€"
  },
  { 
    icon: Zap, 
    title: "IA Calcul mécanique", 
    description: "Forces, couples, cinématique, résistance", 
    image: "https://images.unsplash.com/photo-1485827404703-89b55fcc595e?ixlib=rb-4.0.3&auto=format&fit=crop&w=3840&q=80", 
    monthly: "1 079€/mois",
    oneTime: "17 999€",
    premium: "35 999€"
  },
  { 
    icon: Settings, 
    title: "IA Simulation", 
    description: "Énergie, fluides, efforts et tests virtuels", 
    image: "https://images.unsplash.com/photo-1559292878-4c8b8ad5dbb8?ixlib=rb-4.0.3&auto=format&fit=crop&w=3840&q=80", 
    monthly: "1 289€/mois",
    oneTime: "21 999€",
    premium: "42 999€"
  },
  { 
    icon: Cpu, 
    title: "IA Contrôle", 
    description: "Inspection finale, conformité CE et qualité", 
    image: "https://images.unsplash.com/photo-1565008447742-97f6f38c985c?ixlib=rb-4.0.3&auto=format&fit=crop&w=3840&q=80", 
    monthly: "1 169€/mois",
    oneTime: "19 999€",
    premium: "38 999€"
  },
  { 
    icon: Shield, 
    title: "IA Cybersécurité", 
    description: "Protection maximale contre pirates et hackers 24/7 + surveillance automatique", 
    image: "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?ixlib=rb-4.0.3&auto=format&fit=crop&w=3840&q=80", 
    monthly: "2 399€/mois",
    oneTime: "39 999€",
    premium: "79 999€"
  }
];

const heroImages = [
  "https://images.unsplash.com/photo-1485827404703-89b55fcc595e?ixlib=rb-4.0.3&auto=format&fit=crop&w=3840&q=80", // Robots industriels
  "https://images.unsplash.com/photo-1518709268805-4e9042af2176?ixlib=rb-4.0.3&auto=format&fit=crop&w=3840&q=80", // Centre de données
  "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?ixlib=rb-4.0.3&auto=format&fit=crop&w=3840&q=80", // Cybersécurité
  "https://images.unsplash.com/photo-1563206767-5b18f218e8de?ixlib=rb-4.0.3&auto=format&fit=crop&w=3840&q=80", // Serveur cybersécurité
  "https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&auto=format&fit=crop&w=3840&q=80", // Programmation avancée
  "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?ixlib=rb-4.0.3&auto=format&fit=crop&w=3840&q=80", // IA et données
  "https://images.unsplash.com/photo-1560472354-b33ff0c44a43?ixlib=rb-4.0.3&auto=format&fit=crop&w=3840&q=80", // Technologie quantique
  "https://images.unsplash.com/photo-1563013544-824ae1b704d3?ixlib=rb-4.0.3&auto=format&fit=crop&w=3840&q=80", // Surveillance cyber
  "https://images.unsplash.com/photo-1558494949-ef010cbdcc31?ixlib=rb-4.0.3&auto=format&fit=crop&w=3840&q=80", // Infrastructure sécurisée
  "https://images.unsplash.com/photo-1559827260-dc66d52bef19?ixlib=rb-4.0.3&auto=format&fit=crop&w=3840&q=80", // Ingénierie 3D
  "https://images.unsplash.com/photo-1581094288338-2314dddb7ece?ixlib=rb-4.0.3&auto=format&fit=crop&w=3840&q=80", // Maintenance industrielle
  "https://images.unsplash.com/photo-1565008447742-97f6f38c985c?ixlib=rb-4.0.3&auto=format&fit=crop&w=3840&q=80"  // Machines CNC
];

const videoShowcaseImages = [
  "https://images.unsplash.com/photo-1485827404703-89b55fcc595e?ixlib=rb-4.0.3&auto=format&fit=crop&w=3840&q=80", // Robot industriel en action
  "https://images.unsplash.com/photo-1518709268805-4e9042af2176?ixlib=rb-4.0.3&auto=format&fit=crop&w=3840&q=80", // Serveurs et IA
  "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?ixlib=rb-4.0.3&auto=format&fit=crop&w=3840&q=80", // Écrans de contrôle cybersécurité
  "https://images.unsplash.com/photo-1581094288338-2314dddb7ece?ixlib=rb-4.0.3&auto=format&fit=crop&w=3840&q=80"  // Maintenance prédictive
];

const paymentLogos = [
  { src: "https://upload.wikimedia.org/wikipedia/commons/4/41/Visa_Logo.png", alt: "Visa" },
  { src: "https://upload.wikimedia.org/wikipedia/commons/0/04/Mastercard-logo.png", alt: "Mastercard" },
  { src: "https://upload.wikimedia.org/wikipedia/commons/b/b5/PayPal.svg", alt: "Paypal" },
  { src: "https://upload.wikimedia.org/wikipedia/commons/f/f5/Stripe_Logo%2C_revised_2016.svg", alt: "Stripe" },
  { src: "https://upload.wikimedia.org/wikipedia/commons/4/44/Apple_Pay_logo.svg", alt: "Apple Pay" },
  { src: "https://upload.wikimedia.org/wikipedia/commons/f/04/Maestro_logo.svg", alt: "Maestro" },
  { src: "https://upload.wikimedia.org/wikipedia/commons/0/06/SEPA_Logo.svg", alt: "SEPA" },
  { src: "https://upload.wikimedia.org/wikipedia/commons/a/a2/American_Express_logo_%282018%29.svg", alt: "American Express" }
];

const pricingPlans = [
  {
    name: "Professional",
    price: "4 999€",
    period: "/mois",
    description: "Solution automatisée pour entreprises exigeantes",
    features: [
      "12 assistants IA automatisés 24/7",
      "Cybersécurité militaire grade A+",
      "Mises à jour sécuritaires toutes les 15 jours",
      "Support technique dédié instantané",
      "API sécurisée cryptée AES-256",
      "Formation continue automatisée",
      "Analytics prédictifs en temps réel"
    ],
    popular: false
  },
  {
    name: "Premium",
    price: "9 999€",
    period: "/mois",
    description: "Plateforme complète avec IA autonome avancée",
    features: [
      "17 assistants IA entièrement automatisés",
      "Cybersécurité niveau défense nationale",
      "Mises à jour critiques chaque semaine",
      "Assistant IA personnel dédié",
      "Infrastructure blindée redondante",
      "Conformité militaire OTAN",
      "Monitoring prédictif automatique",
      "Support VIP priorité absolue"
    ],
    popular: true
  },
  {
    name: "Ultra Enterprise",
    price: "19 999€",
    period: "/mois",
    description: "Solution souveraine pour infrastructures critiques",
    features: [
      "25+ assistants IA ultra-spécialisés",
      "Sécurité quantique post-cryptographique",
      "Mises à jour temps réel continues",
      "IA autonome auto-évolutive",
      "Déploiement sur infrastructure privée",
      "Certification défense européenne",
      "Consulting stratégique inclus",
      "Garantie disponibilité 99.99%",
      "Support gouvernemental sécurisé"
    ],
    popular: false
  }
];

const oneTimePurchases = [
  {
    name: "Assistant IA Cybersécurité",
    price: "24 999€",
    description: "Assistant IA permanent spécialisé en cybersécurité militaire",
    features: [
      "Installation et configuration complète",
      "Formation équipe incluse (40h)",
      "Support technique 2 ans",
      "Mises à jour sécuritaires à vie"
    ]
  },
  {
    name: "Suite IA Industrielle Premium",
    price: "49 999€",
    description: "Package complet de 17 IA pour automatisation industrielle",
    features: [
      "Licence perpétuelle",
      "Intégration sur-mesure",
      "Formation avancée équipe (80h)",
      "Support prioritaire 3 ans"
    ]
  },
  {
    name: "Infrastructure IA Souveraine",
    price: "199 999€",
    description: "Déploiement complet sur infrastructure privée sécurisée",
    features: [
      "Serveurs dédiés haute sécurité",
      "Configuration militaire complète",
      "Formation expert (200h)",
      "Maintenance premium 5 ans"
    ]
  }
];

export default function Home() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [currentHeroImage, setCurrentHeroImage] = useState(0);
  const [currentVideoImage, setCurrentVideoImage] = useState(0);
  const [visibleCards, setVisibleCards] = useState<number[]>([]);
  const [scrollY, setScrollY] = useState(0);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
    setMobileMenuOpen(false);
  };

  // Auto-rotate hero images with smooth transitions
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentHeroImage((prev) => (prev + 1) % heroImages.length);
    }, 6000);
    return () => clearInterval(interval);
  }, []);

  // Auto-rotate video showcase images
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentVideoImage((prev) => (prev + 1) % videoShowcaseImages.length);
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  // Parallax scroll effect
  useEffect(() => {
    const handleScroll = () => {
      setScrollY(window.scrollY);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Enhanced card animation with staggered entrance
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const index = parseInt(entry.target.getAttribute('data-index') || '0');
            setTimeout(() => {
              setVisibleCards(prev => {
                if (!prev.includes(index)) {
                  return [...prev, index];
                }
                return prev;
              });
            }, index * 100);
          }
        });
      },
      { threshold: 0.15, rootMargin: '-50px' }
    );

    const cards = document.querySelectorAll('.ai-service-card');
    cards.forEach(card => observer.observe(card));

    return () => observer.disconnect();
  }, []);

  return (
    <div className="min-h-screen bg-dark-bg text-white">
      {/* Header */}
      <header className="bg-dark-card shadow-lg sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-6">
            <div className="flex-shrink-0">
              <h1 className="text-3xl lg:text-4xl font-bold neon-green">MeccabrainIA</h1>
            </div>
            
            {/* Desktop Navigation */}
            <nav className="hidden md:flex space-x-8">
              <button 
                onClick={() => scrollToSection('home')} 
                className="text-white hover:text-[var(--neon-green)] transition-colors duration-300 font-semibold"
              >
                Accueil
              </button>
              <button 
                onClick={() => scrollToSection('services')} 
                className="text-white hover:text-[var(--neon-green)] transition-colors duration-300 font-semibold"
              >
                Nos IA
              </button>
              <button 
                onClick={() => scrollToSection('pricing')} 
                className="text-white hover:text-[var(--neon-green)] transition-colors duration-300 font-semibold"
              >
                Tarifs
              </button>
              <button className="text-white hover:text-[var(--neon-green)] transition-colors duration-300 font-semibold">
                Connexion
              </button>
              <Button className="bg-neon-green text-black px-6 py-2 rounded-lg font-semibold hover:bg-opacity-90 transition-all duration-300">
                Inscription
              </Button>
            </nav>

            {/* Mobile menu button */}
            <div className="md:hidden">
              <button 
                type="button" 
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="text-white hover:text-[var(--neon-green)] transition-colors duration-300"
              >
                {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
              </button>
            </div>
          </div>

          {/* Mobile Navigation */}
          {mobileMenuOpen && (
            <div className="md:hidden pb-6">
              <div className="flex flex-col space-y-4">
                <button 
                  onClick={() => scrollToSection('home')}
                  className="text-white hover:text-[var(--neon-green)] transition-colors duration-300 font-semibold text-left"
                >
                  Accueil
                </button>
                <button 
                  onClick={() => scrollToSection('services')}
                  className="text-white hover:text-[var(--neon-green)] transition-colors duration-300 font-semibold text-left"
                >
                  Nos IA
                </button>
                <button 
                  onClick={() => scrollToSection('pricing')}
                  className="text-white hover:text-[var(--neon-green)] transition-colors duration-300 font-semibold text-left"
                >
                  Tarifs
                </button>
                <button className="text-white hover:text-[var(--neon-green)] transition-colors duration-300 font-semibold text-left">
                  Connexion
                </button>
                <Button className="bg-neon-green text-black px-6 py-2 rounded-lg font-semibold hover:bg-opacity-90 transition-all duration-300 w-fit">
                  Inscription
                </Button>
              </div>
            </div>
          )}
        </div>
      </header>

      {/* Hero Section */}
      <section 
        id="home"
        className="relative h-screen flex items-center justify-center text-center overflow-hidden"
      >
        {/* Background Images with Auto-rotation and Parallax */}
        {heroImages.map((image, index) => (
          <div
            key={index}
            className={`absolute inset-0 transition-opacity duration-2000 ${
              index === currentHeroImage ? 'opacity-100' : 'opacity-0'
            }`}
            style={{
              backgroundImage: `url('${image}')`,
              backgroundSize: "cover",
              backgroundPosition: "center",
              transform: `translateY(${scrollY * 0.5}px)`,
              willChange: 'transform'
            }}
          />
        ))}
        
        {/* Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-black/60 to-black/80"></div>
        
        {/* Floating Elements with Enhanced Animations */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-1/4 left-1/4 w-2 h-2 bg-neon-green rounded-full animate-pulse opacity-60 animate-float"></div>
          <div className="absolute top-1/3 right-1/4 w-1 h-1 bg-neon-green rounded-full animate-pulse opacity-40 animation-delay-1000 animate-float"></div>
          <div className="absolute bottom-1/4 left-1/3 w-3 h-3 bg-neon-green rounded-full animate-pulse opacity-30 animation-delay-2000 animate-float"></div>
          <div className="absolute top-1/2 right-1/3 w-1.5 h-1.5 bg-neon-green rounded-full animate-pulse opacity-50 animation-delay-3000 animate-float"></div>
          
          {/* Animated grid pattern */}
          <div className="absolute inset-0 opacity-5">
            <div className="w-full h-full" style={{
              backgroundImage: `linear-gradient(rgba(0,255,195,0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(0,255,195,0.1) 1px, transparent 1px)`,
              backgroundSize: '100px 100px'
            }}></div>
          </div>
        </div>
        
        <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="animate-fade-in">
            <h2 className="text-5xl md:text-6xl lg:text-7xl font-bold neon-green mb-8 tracking-tight">
              Révolutionnez votre entreprise mécanique
            </h2>
            <p className="text-xl md:text-2xl lg:text-3xl text-white/90 mb-12 max-w-4xl mx-auto font-light">
              16 IA expertes. Automatisées. Disponibles 24h/24.
            </p>
            <div className="flex flex-col sm:flex-row gap-6 justify-center">
              <Button 
                onClick={() => scrollToSection('services')}
                className="bg-neon-green text-black px-10 py-5 rounded-xl font-semibold text-xl hover:bg-opacity-90 transition-all duration-500 transform hover:scale-105 shadow-2xl hover:shadow-neon-green/25"
              >
                Découvrir nos IA
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
              <Button 
                onClick={() => scrollToSection('pricing')}
                variant="outline" 
                className="border-2 border-[var(--neon-green)] text-[var(--neon-green)] px-10 py-5 rounded-xl font-semibold text-xl hover:bg-[var(--neon-green)] hover:text-black transition-all duration-500 backdrop-blur-sm bg-black/20"
              >
                Voir les tarifs
              </Button>
            </div>
          </div>
        </div>

        {/* Progress Indicators */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 flex space-x-2">
          {heroImages.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentHeroImage(index)}
              className={`w-3 h-3 rounded-full transition-all duration-300 ${
                index === currentHeroImage 
                  ? 'bg-neon-green scale-125' 
                  : 'bg-white/40 hover:bg-white/60'
              }`}
            />
          ))}
        </div>
      </section>

      {/* AI Services Section */}
      <section id="services" className="py-20 bg-gradient-to-b from-dark-bg to-dark-card">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16 animate-slide-up">
            <h2 className="text-3xl md:text-4xl font-bold neon-green mb-4">
              Nos Solutions IA Spécialisées
            </h2>
            <p className="text-xl text-muted max-w-3xl mx-auto">
              16 intelligences artificielles expertes pour transformer votre industrie mécanique
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {aiServices.map((service, index) => {
              const IconComponent = service.icon;
              const isVisible = visibleCards.includes(index);
              
              return (
                <Card 
                  key={index}
                  data-index={index}
                  className={`ai-service-card bg-dark-card border-neon-green rounded-xl hover:bg-dark-card-hover transition-all duration-700 cursor-pointer group relative overflow-hidden ${
                    isVisible ? 'animate-slide-up opacity-100' : 'opacity-0 translate-y-8'
                  }`}
                  style={{
                    animationDelay: `${index * 100}ms`,
                    backgroundImage: `linear-gradient(135deg, rgba(0,255,195,0.05) 0%, rgba(0,0,0,0.8) 50%), url('${service.image}')`,
                    backgroundSize: 'cover',
                    backgroundPosition: 'center'
                  }}
                >
                  {/* Hover overlay with image */}
                  <div className="absolute inset-0 bg-black/60 group-hover:bg-black/40 transition-all duration-500"></div>
                  
                  <CardContent className="relative z-10 p-6">
                    <div className="text-[var(--neon-green)] mb-4 group-hover:scale-110 transition-transform duration-300">
                      <IconComponent className="w-8 h-8" />
                    </div>
                    <h3 className="text-xl font-bold neon-green mb-3 group-hover:text-white transition-colors duration-300">
                      {service.title}
                    </h3>
                    <p className="text-muted group-hover:text-white/90 transition-colors duration-300 leading-relaxed mb-4">
                      {service.description}
                    </p>
                    
                    {/* Price display */}
                    <div className="space-y-2 mb-4">
                      <div className="flex justify-between items-center text-xs">
                        <span className="text-white/60">Abonnement:</span>
                        <span className="text-neon-green font-bold">{service.monthly}</span>
                      </div>
                      <div className="flex justify-between items-center text-xs">
                        <span className="text-white/60">Achat unique:</span>
                        <span className="text-neon-green font-bold">{service.oneTime}</span>
                      </div>
                      <div className="flex justify-between items-center text-xs">
                        <span className="text-white/60">Premium:</span>
                        <span className="text-neon-green font-bold">{service.premium}</span>
                      </div>
                    </div>
                    <Button 
                      size="sm" 
                      className="w-full bg-neon-green/20 text-neon-green border border-neon-green hover:bg-neon-green hover:text-black transition-all duration-300"
                    >
                      Commander maintenant
                    </Button>
                    
                    {/* Subtle glow effect */}
                    <div className="absolute inset-0 opacity-0 group-hover:opacity-20 transition-opacity duration-500 bg-gradient-to-t from-[var(--neon-green)] to-transparent"></div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Video Showcase Section */}
      <section className="py-32 bg-black relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-20">
            <h3 className="text-4xl md:text-5xl font-bold neon-green mb-8">
              L'IA industrielle en action
            </h3>
            <p className="text-xl text-white/80 max-w-3xl mx-auto">
              Découvrez comment nos solutions transforment l'industrie mécanique avec des résultats mesurables
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            {/* Video/Demo Area */}
            <div className="relative">
              <div className="aspect-video bg-gradient-to-br from-dark-card via-black to-dark-bg rounded-2xl overflow-hidden border border-neon-green/20">
                <div className="absolute inset-0 flex items-center justify-center">
                  {/* Auto-rotating video preview with industrial imagery */}
                  {videoShowcaseImages.map((image, index) => (
                    <div
                      key={index}
                      className={`absolute inset-0 w-full h-full bg-cover bg-center transition-opacity duration-1500 ${
                        index === currentVideoImage ? 'opacity-100' : 'opacity-0'
                      }`}
                      style={{
                        backgroundImage: `url('${image}')`
                      }}
                    />
                  ))}
                  <div className="absolute inset-0 bg-black/50"></div>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <button className="w-20 h-20 bg-neon-green/20 rounded-full flex items-center justify-center backdrop-blur-sm border border-neon-green hover:bg-neon-green/30 transition-all duration-300 group">
                      <div className="w-0 h-0 border-l-8 border-l-neon-green border-y-6 border-y-transparent ml-1 group-hover:scale-110 transition-transform"></div>
                    </button>
                  </div>
                </div>
              </div>
              
              {/* Floating stats */}
              <div className="absolute -bottom-4 -right-4 bg-dark-card border border-neon-green/30 rounded-xl p-4 backdrop-blur-sm">
                <div className="text-neon-green text-2xl font-bold">99.7%</div>
                <div className="text-white/80 text-sm">Précision IA</div>
              </div>
              
              <div className="absolute -top-4 -left-4 bg-dark-card border border-neon-green/30 rounded-xl p-4 backdrop-blur-sm">
                <div className="text-neon-green text-2xl font-bold">24/7</div>
                <div className="text-white/80 text-sm">Disponible</div>
              </div>
            </div>

            {/* Features List */}
            <div className="space-y-8">
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-neon-green/10 rounded-lg flex items-center justify-center">
                  <Zap className="w-6 h-6 text-neon-green" />
                </div>
                <div>
                  <h4 className="text-xl font-semibold text-white mb-2">Diagnostic instantané</h4>
                  <p className="text-white/70">Analyse en temps réel des pannes et solutions immédiates avec une précision industrielle</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-neon-green/10 rounded-lg flex items-center justify-center">
                  <Settings className="w-6 h-6 text-neon-green" />
                </div>
                <div>
                  <h4 className="text-xl font-semibold text-white mb-2">Maintenance prédictive</h4>
                  <p className="text-white/70">Anticipez les défaillances avant qu'elles n'arrivent et optimisez vos opérations</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-neon-green/10 rounded-lg flex items-center justify-center">
                  <Cpu className="w-6 h-6 text-neon-green" />
                </div>
                <div>
                  <h4 className="text-xl font-semibold text-white mb-2">Automatisation complète</h4>
                  <p className="text-white/70">Intégration seamless avec vos systèmes existants pour une productivité maximale</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Background decoration */}
        <div className="absolute top-0 right-0 w-1/3 h-full bg-gradient-to-l from-neon-green/5 to-transparent"></div>
      </section>

      {/* AI Assistants Automation Section */}
      <section className="py-32 bg-gradient-to-b from-black via-dark-bg to-black relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-red-900/10 via-transparent to-red-900/10"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center mb-20">
            <div className="inline-flex items-center space-x-3 bg-red-900/20 px-6 py-3 rounded-full border border-red-500/30 mb-8">
              <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse"></div>
              <span className="text-red-400 font-bold text-sm">CLASSIFICATION : SÉCURITÉ MAXIMALE</span>
            </div>
            <h3 className="text-4xl md:text-5xl font-bold neon-green mb-8">
              Assistants IA Automatisés
              <br />
              <span className="text-red-400">Niveau Militaire</span>
            </h3>
            <p className="text-xl text-white/80 max-w-4xl mx-auto">
              Nos assistants IA fonctionnent 24/7 en totale autonomie avec une sécurité de grade militaire. 
              Mises à jour automatiques toutes les 15 jours pour une protection maximale.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
            {/* Assistant Cybersécurité */}
            <Card className="bg-gradient-to-br from-red-900/20 to-black border border-red-500/30 rounded-xl overflow-hidden hover:border-red-400/50 transition-all duration-300">
              <CardContent className="p-6">
                <div className="flex items-center space-x-3 mb-4">
                  <div className="w-12 h-12 bg-red-500/20 rounded-full flex items-center justify-center">
                    <Shield className="w-6 h-6 text-red-400" />
                  </div>
                  <div>
                    <h4 className="text-lg font-bold text-white">Assistant Cybersécurité</h4>
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                      <span className="text-green-400 text-sm">ACTIF 24/7</span>
                    </div>
                  </div>
                </div>
                <ul className="space-y-2 text-white/80 text-sm">
                  <li>• Surveillance temps réel des menaces</li>
                  <li>• Analyse comportementale avancée</li>
                  <li>• Réponse automatique aux incidents</li>
                  <li>• Conformité OTAN/ANSSI</li>
                </ul>
              </CardContent>
            </Card>

            {/* Assistant Maintenance */}
            <Card className="bg-gradient-to-br from-dark-card to-black border border-neon-green/30 rounded-xl overflow-hidden hover:border-neon-green/50 transition-all duration-300">
              <CardContent className="p-6">
                <div className="flex items-center space-x-3 mb-4">
                  <div className="w-12 h-12 bg-neon-green/20 rounded-full flex items-center justify-center">
                    <Settings className="w-6 h-6 text-neon-green" />
                  </div>
                  <div>
                    <h4 className="text-lg font-bold text-white">Assistant Maintenance</h4>
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                      <span className="text-green-400 text-sm">AUTOMATISÉ</span>
                    </div>
                  </div>
                </div>
                <ul className="space-y-2 text-white/80 text-sm">
                  <li>• Maintenance prédictive automatique</li>
                  <li>• Optimisation énergétique continue</li>
                  <li>• Planification intelligente</li>
                  <li>• Reporting automatisé</li>
                </ul>
              </CardContent>
            </Card>

            {/* Assistant Diagnostic */}
            <Card className="bg-gradient-to-br from-dark-card to-black border border-neon-green/30 rounded-xl overflow-hidden hover:border-neon-green/50 transition-all duration-300">
              <CardContent className="p-6">
                <div className="flex items-center space-x-3 mb-4">
                  <div className="w-12 h-12 bg-neon-green/20 rounded-full flex items-center justify-center">
                    <Zap className="w-6 h-6 text-neon-green" />
                  </div>
                  <div>
                    <h4 className="text-lg font-bold text-white">Assistant Diagnostic</h4>
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                      <span className="text-green-400 text-sm">TEMPS RÉEL</span>
                    </div>
                  </div>
                </div>
                <ul className="space-y-2 text-white/80 text-sm">
                  <li>• Diagnostic instantané automatique</li>
                  <li>• Analyse multi-capteurs en temps réel</li>
                  <li>• Solutions automatiques proposées</li>
                  <li>• Apprentissage continu</li>
                </ul>
              </CardContent>
            </Card>
          </div>

          {/* Security Features */}
          <div className="bg-gradient-to-r from-red-900/10 via-black to-red-900/10 border border-red-500/20 rounded-2xl p-8 mb-16">
            <h4 className="text-2xl font-bold text-center text-red-400 mb-8">
              Sécurité Niveau Défense
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="text-center">
                <div className="w-16 h-16 bg-red-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Shield className="w-8 h-8 text-red-400" />
                </div>
                <h5 className="font-bold text-white mb-2">Cryptage AES-256</h5>
                <p className="text-white/70 text-sm">Chiffrement militaire pour toutes les communications</p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-red-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Clock className="w-8 h-8 text-red-400" />
                </div>
                <h5 className="font-bold text-white mb-2">Mises à jour 15j</h5>
                <p className="text-white/70 text-sm">Patches de sécurité automatiques toutes les 2 semaines</p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-red-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Eye className="w-8 h-8 text-red-400" />
                </div>
                <h5 className="font-bold text-white mb-2">Monitoring 24/7</h5>
                <p className="text-white/70 text-sm">Surveillance continue par nos IA de sécurité</p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-red-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Cpu className="w-8 h-8 text-red-400" />
                </div>
                <h5 className="font-bold text-white mb-2">IA Autonome</h5>
                <p className="text-white/70 text-sm">Systèmes auto-évolutifs sans intervention humaine</p>
              </div>
            </div>
          </div>

          {/* Powered by MeccabrainIA */}
          <div className="text-center">
            <div className="inline-flex items-center space-x-4 bg-dark-card border border-neon-green/30 rounded-xl px-8 py-6">
              <div className="w-12 h-12 bg-neon-green/20 rounded-full flex items-center justify-center">
                <Cpu className="w-6 h-6 text-neon-green" />
              </div>
              <div className="text-left">
                <h5 className="text-lg font-bold neon-green">Conçu par l'IA MeccabrainIA</h5>
                <p className="text-white/70 text-sm">Plateforme auto-générée et auto-optimisée par intelligence artificielle</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-32 bg-gradient-to-b from-dark-bg via-dark-card to-dark-bg relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-20">
            <h3 className="text-4xl md:text-5xl font-bold neon-green mb-8">
              Tarifs transparents, puissance maximale
            </h3>
            <p className="text-xl text-white/80 max-w-3xl mx-auto">
              Choisissez la solution qui correspond à votre entreprise. Toutes nos offres incluent un accès complet à l'IA de pointe.
            </p>
          </div>

          {/* Abonnements mensuels */}
          <div className="mb-20">
            <h4 className="text-2xl font-bold text-center text-white mb-8">
              Abonnements Premium Automatisés
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
              {pricingPlans.map((plan, index) => (
                <Card 
                  key={index}
                  className={`relative bg-dark-card border-2 rounded-2xl overflow-hidden transition-all duration-500 hover:scale-105 ${
                    plan.popular 
                      ? 'border-neon-green shadow-2xl shadow-neon-green/20' 
                      : 'border-neon-green/30 hover:border-neon-green/60'
                  }`}
                >
                  {plan.popular && (
                    <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                      <div className="bg-neon-green text-black px-6 py-2 rounded-full font-bold text-sm">
                        RECOMMANDÉ
                      </div>
                    </div>
                  )}
                  
                  <CardContent className="p-8">
                    <div className="text-center mb-8">
                      <h4 className="text-2xl font-bold text-white mb-2">{plan.name}</h4>
                      <p className="text-white/70 mb-6">{plan.description}</p>
                      <div className="flex items-baseline justify-center">
                        <span className="text-4xl font-bold neon-green">{plan.price}</span>
                        <span className="text-white/60 ml-2">{plan.period}</span>
                      </div>
                    </div>
                    
                    <ul className="space-y-4 mb-8">
                      {plan.features.map((feature, featureIndex) => (
                        <li key={featureIndex} className="flex items-start">
                          <div className="w-5 h-5 rounded-full bg-neon-green/20 flex items-center justify-center mt-0.5 mr-3">
                            <div className="w-2 h-2 bg-neon-green rounded-full"></div>
                          </div>
                          <span className="text-white/90">{feature}</span>
                        </li>
                      ))}
                    </ul>
                    
                    <Button 
                      className={`w-full py-4 rounded-xl font-semibold text-lg transition-all duration-300 ${
                        plan.popular
                          ? 'bg-neon-green text-black hover:bg-neon-green/90 shadow-lg hover:shadow-neon-green/25'
                          : 'bg-transparent border-2 border-neon-green text-neon-green hover:bg-neon-green hover:text-black'
                      }`}
                    >
                      Démarrer l'abonnement
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Achats uniques premium */}
          <div className="mb-16">
            <h4 className="text-2xl font-bold text-center text-white mb-8">
              Solutions Premium - Achat Unique
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {oneTimePurchases.map((purchase, index) => (
                <Card 
                  key={index}
                  className="bg-gradient-to-br from-dark-card to-black border border-neon-green/40 rounded-2xl overflow-hidden transition-all duration-500 hover:scale-105 hover:border-neon-green/70"
                >
                  <CardContent className="p-8">
                    <div className="text-center mb-8">
                      <h4 className="text-xl font-bold text-white mb-2">{purchase.name}</h4>
                      <p className="text-white/70 mb-6">{purchase.description}</p>
                      <div className="flex items-baseline justify-center">
                        <span className="text-3xl font-bold neon-green">{purchase.price}</span>
                        <span className="text-white/60 ml-2">unique</span>
                      </div>
                    </div>
                    
                    <ul className="space-y-3 mb-8">
                      {purchase.features.map((feature, featureIndex) => (
                        <li key={featureIndex} className="flex items-start">
                          <div className="w-4 h-4 rounded-full bg-neon-green/20 flex items-center justify-center mt-1 mr-3">
                            <div className="w-1.5 h-1.5 bg-neon-green rounded-full"></div>
                          </div>
                          <span className="text-white/90 text-sm">{feature}</span>
                        </li>
                      ))}
                    </ul>
                    
                    <Button className="w-full py-3 rounded-xl font-semibold border-2 border-neon-green text-neon-green hover:bg-neon-green hover:text-black transition-all duration-300">
                      Acheter maintenant
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Enterprise Contact */}
          <div className="text-center">
            <Card className="bg-gradient-to-r from-dark-card to-black border-neon-green/50 rounded-2xl inline-block">
              <CardContent className="p-8">
                <h4 className="text-xl font-bold text-white mb-4">
                  Besoin d'une solution sur-mesure ?
                </h4>
                <p className="text-white/70 mb-6">
                  Contactez notre équipe pour une offre personnalisée adaptée à vos besoins spécifiques.
                </p>
                <Button className="bg-transparent border-2 border-neon-green text-neon-green hover:bg-neon-green hover:text-black transition-all duration-300 px-8 py-3">
                  Contacter nos experts
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* System Status Section */}
      <section className="py-20 bg-gradient-to-b from-dark-bg to-black relative">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h3 className="text-3xl md:text-4xl font-bold neon-green mb-6">
              Statut Système en Temps Réel
            </h3>
            <p className="text-xl text-white/80 max-w-3xl mx-auto">
              Surveillance continue de tous nos systèmes IA avec mises à jour automatiques toutes les 15 jours
            </p>
          </div>

          {/* Real-time Security Dashboard */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
            <div className="bg-dark-card border border-red-500/50 rounded-xl p-6 text-center relative overflow-hidden">
              <div className="absolute top-0 right-0 w-2 h-2 bg-red-500 rounded-full animate-ping"></div>
              <div className="w-4 h-4 bg-red-500 rounded-full mx-auto mb-4 animate-pulse"></div>
              <h4 className="text-lg font-bold text-white mb-2">IA Anti-Piratage</h4>
              <p className="text-red-400 text-sm font-semibold">SURVEILLANCE ACTIVE</p>
              <p className="text-white/60 text-xs mt-2">Blocages aujourd'hui: 847</p>
            </div>
            
            <div className="bg-dark-card border border-green-500/30 rounded-xl p-6 text-center">
              <div className="w-4 h-4 bg-green-500 rounded-full mx-auto mb-4 animate-pulse"></div>
              <h4 className="text-lg font-bold text-white mb-2">Infrastructure</h4>
              <p className="text-green-400 text-sm font-semibold">99.99% UPTIME</p>
              <p className="text-white/60 text-xs mt-2">Redondance triple active</p>
            </div>
            
            <div className="bg-dark-card border border-green-500/30 rounded-xl p-6 text-center">
              <div className="w-4 h-4 bg-green-500 rounded-full mx-auto mb-4 animate-pulse"></div>
              <h4 className="text-lg font-bold text-white mb-2">API Services</h4>
              <p className="text-green-400 text-sm font-semibold">ULTRA PERFORMANCE</p>
              <p className="text-white/60 text-xs mt-2">Réponse: 8ms</p>
            </div>
            
            <div className="bg-dark-card border border-green-500/30 rounded-xl p-6 text-center relative">
              <div className="absolute top-2 right-2 w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
              <div className="w-4 h-4 bg-green-500 rounded-full mx-auto mb-4 animate-pulse"></div>
              <h4 className="text-lg font-bold text-white mb-2">Sécurité</h4>
              <p className="text-green-400 text-sm font-semibold">NIVEAU DÉFENSE</p>
              <p className="text-white/60 text-xs mt-2">Cryptage quantique</p>
            </div>
          </div>

          {/* Advanced Cybersecurity Monitoring */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
            <div className="bg-gradient-to-br from-red-900/20 to-black border border-red-500/30 rounded-xl p-6">
              <div className="flex items-center space-x-3 mb-4">
                <Shield className="w-6 h-6 text-red-400" />
                <h5 className="text-lg font-bold text-white">Détection Pirates</h5>
              </div>
              <div className="text-3xl font-bold text-red-400 mb-2">24/7</div>
              <p className="text-white/70 text-sm">Surveillance automatique continue avec blocage instantané des intrusions</p>
              <div className="mt-4 text-xs text-red-400">
                • 1,247 tentatives bloquées cette semaine
                • IA autonome de détection comportementale
                • Réponse automatique en 0.03 secondes
              </div>
            </div>
            
            <div className="bg-gradient-to-br from-yellow-900/20 to-black border border-yellow-500/30 rounded-xl p-6">
              <div className="flex items-center space-x-3 mb-4">
                <Eye className="w-6 h-6 text-yellow-400" />
                <h5 className="text-lg font-bold text-white">Monitoring Hackers</h5>
              </div>
              <div className="text-3xl font-bold text-yellow-400 mb-2">ACTIF</div>
              <p className="text-white/70 text-sm">Analyse prédictive des patterns d'attaque avec géolocalisation</p>
              <div className="mt-4 text-xs text-yellow-400">
                • Base de données 500M+ signatures
                • Machine learning temps réel
                • Alertes gouvernementales intégrées
              </div>
            </div>
            
            <div className="bg-gradient-to-br from-green-900/20 to-black border border-green-500/30 rounded-xl p-6">
              <div className="flex items-center space-x-3 mb-4">
                <Cpu className="w-6 h-6 text-green-400" />
                <h5 className="text-lg font-bold text-white">IA Auto-Défense</h5>
              </div>
              <div className="text-3xl font-bold text-green-400 mb-2">ÉVOLUTIVE</div>
              <p className="text-white/70 text-sm">Système auto-apprenant qui s'adapte aux nouvelles menaces</p>
              <div className="mt-4 text-xs text-green-400">
                • Évolution autonome continue
                • Contre-attaques automatiques
                • Certification OTAN niveau SECRET
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-r from-dark-card to-black border border-neon-green/30 rounded-2xl p-8 text-center">
            <h4 className="text-2xl font-bold text-white mb-4">Prochaine mise à jour sécuritaire</h4>
            <div className="flex justify-center items-center space-x-8 mb-6">
              <div className="text-center">
                <div className="text-3xl font-bold neon-green">11</div>
                <div className="text-white/60 text-sm">JOURS</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold neon-green">14</div>
                <div className="text-white/60 text-sm">HEURES</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold neon-green">32</div>
                <div className="text-white/60 text-sm">MINUTES</div>
              </div>
            </div>
            <p className="text-white/70">Mise à jour automatique du système de sécurité et de tous les assistants IA</p>
          </div>
        </div>
      </section>

      {/* Support Section */}
      <section className="py-20 bg-dark-card relative">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h3 className="text-3xl md:text-4xl font-bold neon-green mb-6">
            Support IA Automatisé 24h/24
          </h3>
          <p className="text-xl text-muted mb-8 max-w-2xl mx-auto">
            Nos assistants IA répondent instantanément à toutes vos demandes techniques, commerciales ou de support.
          </p>
          <div className="bg-dark-bg border-neon-green border rounded-xl p-8 mb-8 backdrop-blur-sm bg-black/40">
            <p className="text-lg text-muted mb-4">Contact direct sécurisé :</p>
            <a 
              href="mailto:support@meccabrainia.eu" 
              className="neon-green text-xl font-semibold hover:underline transition-all duration-300"
            >
              support@meccabrainia.eu
            </a>
            <div className="mt-4 flex justify-center items-center space-x-4 text-white/60 text-sm">
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                <span>Réponse garantie sous 30 secondes</span>
              </div>
            </div>
          </div>
          <Button className="bg-neon-green text-black px-8 py-4 rounded-lg font-semibold text-lg hover:bg-opacity-90 transition-all duration-300 transform hover:scale-105 animate-glow">
            Démarrer maintenant
          </Button>
        </div>
      </section>

      {/* Payment Methods Section */}
      <section className="py-20 bg-gradient-to-r from-dark-bg via-dark-card to-dark-bg border-t border-neon-green/20">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h4 className="text-2xl font-bold text-white mb-4">
              Paiements sécurisés et flexibles
            </h4>
            <p className="text-white/70 max-w-2xl mx-auto">
              Toutes les transactions sont cryptées et sécurisées. Choisissez votre méthode de paiement préférée.
            </p>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-6 items-center">
            {paymentLogos.map((logo, index) => (
              <div 
                key={index}
                className="bg-white/5 backdrop-blur-sm rounded-xl p-4 border border-neon-green/10 hover:border-neon-green/30 transition-all duration-300 hover:scale-105 group"
              >
                <img 
                  src={logo.src} 
                  alt={logo.alt} 
                  className="h-8 w-full object-contain filter brightness-0 invert group-hover:brightness-100 group-hover:invert-0 transition-all duration-300" 
                />
              </div>
            ))}
          </div>
          
          <div className="text-center mt-12">
            <div className="inline-flex items-center space-x-6 text-white/60">
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-neon-green rounded-full"></div>
                <span>Paiement sécurisé SSL</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-neon-green rounded-full"></div>
                <span>Conformité PCI DSS</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-neon-green rounded-full"></div>
                <span>Support 24/7</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Test Services Section */}
      <section className="py-32 bg-gradient-to-b from-black to-dark-bg relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-20">
            <h3 className="text-5xl font-bold neon-green mb-8">
              Testez nos services IA avant achat
            </h3>
            <p className="text-xl text-white/80 max-w-4xl mx-auto">
              Découvrez la puissance de nos assistants IA avec des démonstrations complètes dans toutes les langues
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
            <div className="bg-dark-card border border-neon-green/30 rounded-xl p-8 hover:border-neon-green transition-all duration-300">
              <div className="text-center">
                <Shield className="w-12 h-12 text-neon-green mx-auto mb-4" />
                <h4 className="text-xl font-bold text-white mb-4">Test IA Cybersécurité</h4>
                <div className="space-y-2 mb-6 text-sm">
                  <div className="flex justify-between">
                    <span className="text-white/60">Abonnement:</span>
                    <span className="text-neon-green font-bold">2 399€/mois</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-white/60">Achat unique:</span>
                    <span className="text-neon-green font-bold">39 999€</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-white/60">Premium:</span>
                    <span className="text-neon-green font-bold">79 999€</span>
                  </div>
                </div>
                <Button className="w-full bg-neon-green text-black hover:bg-neon-green/80">
                  Tester gratuitement
                </Button>
              </div>
            </div>

            <div className="bg-dark-card border border-neon-green/30 rounded-xl p-8 hover:border-neon-green transition-all duration-300">
              <div className="text-center">
                <Cpu className="w-12 h-12 text-neon-green mx-auto mb-4" />
                <h4 className="text-xl font-bold text-white mb-4">Test IA Automatisation</h4>
                <div className="space-y-2 mb-6 text-sm">
                  <div className="flex justify-between">
                    <span className="text-white/60">Abonnement:</span>
                    <span className="text-neon-green font-bold">2 099€/mois</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-white/60">Achat unique:</span>
                    <span className="text-neon-green font-bold">34 999€</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-white/60">Premium:</span>
                    <span className="text-neon-green font-bold">69 999€</span>
                  </div>
                </div>
                <Button className="w-full bg-neon-green text-black hover:bg-neon-green/80">
                  Tester gratuitement
                </Button>
              </div>
            </div>

            <div className="bg-dark-card border border-neon-green/30 rounded-xl p-8 hover:border-neon-green transition-all duration-300">
              <div className="text-center">
                <Zap className="w-12 h-12 text-neon-green mx-auto mb-4" />
                <h4 className="text-xl font-bold text-white mb-4">Test IA Conception</h4>
                <div className="space-y-2 mb-6 text-sm">
                  <div className="flex justify-between">
                    <span className="text-white/60">Abonnement:</span>
                    <span className="text-neon-green font-bold">1 499€/mois</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-white/60">Achat unique:</span>
                    <span className="text-neon-green font-bold">24 999€</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-white/60">Premium:</span>
                    <span className="text-neon-green font-bold">49 999€</span>
                  </div>
                </div>
                <Button className="w-full bg-neon-green text-black hover:bg-neon-green/80">
                  Tester gratuitement
                </Button>
              </div>
            </div>
          </div>

          <div className="text-center">
            <div className="bg-gradient-to-r from-neon-green/10 to-transparent border border-neon-green/30 rounded-xl p-8 max-w-5xl mx-auto">
              <h4 className="text-2xl font-bold text-white mb-6">Tests disponibles en plusieurs langues</h4>
              <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-4 text-sm text-white/70">
                <div className="flex items-center space-x-2">
                  <span>🇫🇷</span>
                  <span>Français</span>
                </div>
                <div className="flex items-center space-x-2">
                  <span>🇬🇧</span>
                  <span>English</span>
                </div>
                <div className="flex items-center space-x-2">
                  <span>🇩🇪</span>
                  <span>Deutsch</span>
                </div>
                <div className="flex items-center space-x-2">
                  <span>🇪🇸</span>
                  <span>Español</span>
                </div>
                <div className="flex items-center space-x-2">
                  <span>🇮🇹</span>
                  <span>Italiano</span>
                </div>
                <div className="flex items-center space-x-2">
                  <span>🇵🇹</span>
                  <span>Português</span>
                </div>
                <div className="flex items-center space-x-2">
                  <span>🇳🇱</span>
                  <span>Nederlands</span>
                </div>
                <div className="flex items-center space-x-2">
                  <span>🇯🇵</span>
                  <span>日本語</span>
                </div>
              </div>
              <div className="mt-6 text-center">
                <Button className="bg-gradient-to-r from-neon-green to-green-400 text-black font-bold px-8 py-4 text-lg hover:scale-105 transition-transform duration-300">
                  Commencer les tests gratuits
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gradient-to-b from-dark-bg to-black border-t border-red-500/20 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
            <div className="col-span-1 md:col-span-2">
              <h3 className="text-3xl font-bold neon-green mb-6">MeccabrainIA</h3>
              <p className="text-white/80 mb-6 text-lg">
                Plateforme d'intelligence artificielle autonome pour l'industrie 4.0. 
                25+ assistants IA spécialisés avec sécurité militaire.
              </p>
              <div className="bg-dark-card border border-neon-green/30 rounded-xl p-6 mb-6">
                <div className="flex items-center space-x-3 mb-3">
                  <div className="w-8 h-8 bg-neon-green/20 rounded-full flex items-center justify-center">
                    <Cpu className="w-4 h-4 text-neon-green" />
                  </div>
                  <h5 className="text-lg font-bold neon-green">Conçu par IA MeccabrainIA</h5>
                </div>
                <p className="text-white/70 text-sm">
                  Cette plateforme a été entièrement générée, optimisée et maintenue par notre système d'intelligence artificielle. 
                  Auto-évolution continue basée sur l'apprentissage machine avancé.
                </p>
              </div>
            </div>
            <div>
              <h4 className="text-xl font-semibold text-white mb-6">Services IA Premium</h4>
              <ul className="space-y-3 text-white/80">
                <li><button onClick={() => scrollToSection('services')} className="hover:text-[var(--neon-green)] transition-colors duration-300 flex items-center text-left"><span className="w-2 h-2 bg-neon-green rounded-full mr-3 flex-shrink-0"></span>IA Cybersécurité - 2 399€/mois</button></li>
                <li><button onClick={() => scrollToSection('pricing')} className="hover:text-[var(--neon-green)] transition-colors duration-300 flex items-center text-left"><span className="w-2 h-2 bg-neon-green rounded-full mr-3 flex-shrink-0"></span>IA Automatisation - 2 099€/mois</button></li>
                <li><a href="#" className="hover:text-[var(--neon-green)] transition-colors duration-300 flex items-center text-left"><span className="w-2 h-2 bg-neon-green rounded-full mr-3 flex-shrink-0"></span>IA Robotique - 1 799€/mois</a></li>
                <li><a href="#" className="hover:text-[var(--neon-green)] transition-colors duration-300 flex items-center text-left"><span className="w-2 h-2 bg-neon-green rounded-full mr-3 flex-shrink-0"></span>Tests gratuits disponibles</a></li>
              </ul>
            </div>
            <div>
              <h4 className="text-xl font-semibold text-white mb-6">Support & Sécurité</h4>
              <ul className="space-y-3 text-white/80">
                <li><a href="#" className="hover:text-[var(--neon-green)] transition-colors duration-300 flex items-center"><span className="w-2 h-2 bg-red-400 rounded-full mr-3"></span>Centre de Sécurité</a></li>
                <li><a href="mailto:support@meccabrainia.eu" className="hover:text-[var(--neon-green)] transition-colors duration-300 flex items-center"><span className="w-2 h-2 bg-green-500 rounded-full mr-3"></span>Support IA 24/7</a></li>
                <li><a href="#" className="hover:text-[var(--neon-green)] transition-colors duration-300 flex items-center"><span className="w-2 h-2 bg-neon-green rounded-full mr-3"></span>Statut Système</a></li>
                <li><a href="#" className="hover:text-[var(--neon-green)] transition-colors duration-300 flex items-center"><span className="w-2 h-2 bg-neon-green rounded-full mr-3"></span>Communauté</a></li>
              </ul>
            </div>
          </div>
          
          {/* Security Certifications */}
          <div className="border-t border-red-500/20 pt-8 mb-8">
            <div className="text-center mb-6">
              <h5 className="text-lg font-bold text-red-400 mb-4">Certifications de Sécurité</h5>
              <div className="flex flex-wrap justify-center items-center gap-8 text-white/60 text-sm">
                <div className="flex items-center space-x-2">
                  <Shield className="w-4 h-4 text-red-400" />
                  <span>Certifié ANSSI</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Shield className="w-4 h-4 text-red-400" />
                  <span>Conformité OTAN</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Shield className="w-4 h-4 text-red-400" />
                  <span>ISO 27001</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Shield className="w-4 h-4 text-red-400" />
                  <span>SOC 2 Type II</span>
                </div>
              </div>
            </div>
          </div>

          <div className="border-t border-gray-800 pt-8 flex flex-col md:flex-row justify-between items-center">
            <div className="text-center md:text-left mb-4 md:mb-0">
              <p className="text-white/80 text-sm mb-2">
                © 2025 MeccabrainIA – Plateforme autonome développée par IA
              </p>
              <p className="text-white/60 text-xs">
                Mise à jour automatique continue • Sécurité niveau militaire • Support IA instantané
              </p>
            </div>
            <div className="flex flex-col md:flex-row space-y-2 md:space-y-0 md:space-x-6 text-sm text-white/60">
              <a href="#" className="hover:text-[var(--neon-green)] transition-colors duration-300">Politique de confidentialité</a>
              <a href="#" className="hover:text-[var(--neon-green)] transition-colors duration-300">Conditions d'utilisation</a>
              <a href="#" className="hover:text-[var(--neon-green)] transition-colors duration-300">Mentions légales</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
