# MeccabrainIA - AI Industrial Services Platform

## Overview

This is a complete, enterprise-ready AI platform for MeccabrainIA, featuring 25+ automated AI assistants for industrial services with military-grade cybersecurity. The platform includes advanced pricing tiers (Professional €4,999/month, Premium €9,999/month, Ultra Enterprise €19,999/month), premium one-time purchases (up to €199,999), and comprehensive payment integration. Built with autonomous AI assistants, real-time system monitoring, and automatic security updates every 15 days. The entire platform is designed as a fully operational business website ready for deployment and commercial use.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

The application follows a monorepo structure with clear separation between client and server code:

- **Frontend**: React 18+ with TypeScript, using Vite for development and build tooling
- **Backend**: Express.js with TypeScript, configured for ESM modules
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **UI Framework**: Tailwind CSS with shadcn/ui component library
- **State Management**: TanStack Query for server state management
- **Routing**: Wouter for client-side routing

## Key Components

### Frontend Architecture
- **Component System**: Built on shadcn/ui with Radix UI primitives for accessibility
- **Styling**: Tailwind CSS with custom design tokens for dark theme and neon green accents
- **Type Safety**: Full TypeScript coverage with strict configuration
- **State Management**: TanStack Query for API state, React hooks for local state
- **Build System**: Vite with custom configuration for development and production

### Backend Architecture
- **Server Framework**: Express.js with TypeScript and ESM module support
- **Database Layer**: Drizzle ORM with PostgreSQL dialect
- **Development**: Hot reloading with tsx, custom logging middleware
- **Error Handling**: Centralized error handling middleware
- **API Structure**: RESTful design with `/api` prefix for all endpoints

### Database Schema
- **Users Table**: Basic user entity with id, username, and password fields
- **Schema Validation**: Drizzle-zod integration for runtime type checking
- **Migrations**: Drizzle-kit for database schema management

### UI/UX Design
- **Theme**: Dark mode optimized with custom MeccabrainIA branding
- **Colors**: Neon green primary (#00ffc3), dark backgrounds, high contrast
- **Responsive**: Mobile-first design with Tailwind breakpoints
- **Accessibility**: Radix UI primitives ensure WCAG compliance

## Data Flow

1. **Client Requests**: React components use TanStack Query for API calls
2. **API Layer**: Express routes handle HTTP requests with middleware chain
3. **Data Access**: Storage interface abstracts database operations
4. **Response**: JSON responses with consistent error handling
5. **State Updates**: TanStack Query manages cache invalidation and updates

The application currently uses an in-memory storage implementation but is architected to easily switch to PostgreSQL database persistence.

## External Dependencies

### Core Framework Dependencies
- **React Ecosystem**: React 18, React DOM, TypeScript support
- **Build Tools**: Vite, ESBuild for production builds
- **Database**: Drizzle ORM, @neondatabase/serverless, PostgreSQL support
- **UI Components**: Full shadcn/ui suite with Radix UI primitives

### Development Tools
- **Replit Integration**: Custom cartographer plugin, runtime error overlay
- **Type Checking**: TypeScript with strict configuration
- **Styling**: Tailwind CSS, PostCSS, Autoprefixer
- **Code Quality**: ESM modules, path aliases for clean imports

### Third-party Services
- **Database Provider**: Configured for Neon Database (PostgreSQL)
- **Payment Processing**: Ready for Stripe, PayPal, Apple Pay integration
- **External APIs**: Extensible architecture for AI service integrations

## Deployment Strategy

### Development Environment
- **Local Development**: Vite dev server with HMR and Express backend
- **Database**: Environment variable configuration for DATABASE_URL
- **Hot Reloading**: tsx for TypeScript execution, Vite for frontend changes

### Production Build
- **Frontend**: Vite build to `dist/public` directory
- **Backend**: ESBuild bundle to `dist/index.js` with external packages
- **Static Assets**: Express serves built frontend in production mode
- **Database Migrations**: Drizzle-kit push command for schema updates

### Environment Configuration
- **Database**: PostgreSQL connection via DATABASE_URL environment variable
- **Build Process**: Separate build steps for frontend and backend
- **Process Management**: Node.js production server with error handling
- **Replit Compatibility**: Special handling for Replit development environment

The application is structured for easy deployment to various hosting platforms while maintaining development experience optimization for Replit environment.